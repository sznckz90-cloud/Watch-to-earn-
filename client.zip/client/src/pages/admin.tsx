import { useState, useEffect } from "react";
import { useUserData } from "@/hooks/use-user-data";

interface AdminStats {
  totalUsers: number;
  totalAds: number;
  totalEarnings: string;
  activeUsers: number;
}

interface UserData {
  id: string;
  username: string;
  telegramId: string | null;
  level: number;
  totalAds: number;
  totalEarned: string;
  withdrawBalance: string;
  referralsCount: number;
  createdAt: string;
}

function Admin() {
  const { data: currentUser } = useUserData();
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<UserData[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'stats' | 'users' | 'withdrawals'>('stats');

  // Check if current user is admin
  const isAdmin = currentUser?.telegramId === "6653616672";

  useEffect(() => {
    if (!isAdmin) return;
    
    fetchAdminData();
  }, [isAdmin]);

  const fetchAdminData = async () => {
    try {
      setLoading(true);
      
      // Fetch admin stats
      const statsResponse = await fetch('/api/admin/stats');
      if (statsResponse.ok) {
        const statsData = await statsResponse.json();
        setStats(statsData);
      }

      // Fetch all users
      const usersResponse = await fetch('/api/admin/users');
      if (usersResponse.ok) {
        const usersData = await usersResponse.json();
        setUsers(usersData);
      }
    } catch (error) {
      console.error('Failed to fetch admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  // If not admin, show access denied
  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-140px)] px-4">
        <div className="text-center">
          <div className="text-6xl mb-4">🔒</div>
          <h2 className="text-2xl font-bold text-white mb-2">Access Denied</h2>
          <p className="text-gray-400">You don't have admin privileges to access this panel.</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-140px)]">
        <div className="animate-spin text-primary text-2xl">
          <i className="fas fa-spinner"></i>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-20 px-4">
      {/* Admin Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white mb-2">
          <i className="fas fa-shield-alt text-primary mr-2"></i>
          Admin Panel
        </h1>
        <p className="text-gray-400">Manage your Lightning Sats platform</p>
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 bg-gray-800 rounded-xl p-1 mb-6">
        <button
          onClick={() => setActiveTab('stats')}
          className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
            activeTab === 'stats'
              ? 'bg-primary text-white'
              : 'text-gray-400 hover:text-white'
          }`}
          data-testid="tab-stats"
        >
          <i className="fas fa-chart-bar mr-2"></i>
          Stats
        </button>
        <button
          onClick={() => setActiveTab('users')}
          className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
            activeTab === 'users'
              ? 'bg-primary text-white'
              : 'text-gray-400 hover:text-white'
          }`}
          data-testid="tab-users"
        >
          <i className="fas fa-users mr-2"></i>
          Users
        </button>
        <button
          onClick={() => setActiveTab('withdrawals')}
          className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
            activeTab === 'withdrawals'
              ? 'bg-primary text-white'
              : 'text-gray-400 hover:text-white'
          }`}
          data-testid="tab-withdrawals"
        >
          <i className="fas fa-money-bill-wave mr-2"></i>
          Withdrawals
        </button>
      </div>

      {/* Stats Tab */}
      {activeTab === 'stats' && stats && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-card p-4 rounded-xl border border-border">
              <div className="text-2xl font-bold text-primary" data-testid="stat-total-users">
                {stats.totalUsers}
              </div>
              <div className="text-sm text-gray-400">Total Users</div>
            </div>
            <div className="bg-card p-4 rounded-xl border border-border">
              <div className="text-2xl font-bold text-success" data-testid="stat-active-users">
                {stats.activeUsers}
              </div>
              <div className="text-sm text-gray-400">Active Today</div>
            </div>
            <div className="bg-card p-4 rounded-xl border border-border">
              <div className="text-2xl font-bold text-warning" data-testid="stat-total-ads">
                {stats.totalAds.toLocaleString()}
              </div>
              <div className="text-sm text-gray-400">Total Ads</div>
            </div>
            <div className="bg-card p-4 rounded-xl border border-border">
              <div className="text-2xl font-bold text-info" data-testid="stat-total-earnings">
                ${parseFloat(stats.totalEarnings).toFixed(2)}
              </div>
              <div className="text-sm text-gray-400">Platform Earnings</div>
            </div>
          </div>
        </div>
      )}

      {/* Users Tab */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-white">All Users</h3>
            <button
              onClick={fetchAdminData}
              className="bg-primary hover:bg-primary-dark px-3 py-1 rounded-lg text-sm"
              data-testid="button-refresh-users"
            >
              <i className="fas fa-sync-alt mr-1"></i>
              Refresh
            </button>
          </div>
          
          <div className="space-y-3">
            {users.map((user) => (
              <div key={user.id} className="bg-card p-4 rounded-xl border border-border">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="font-semibold text-white" data-testid={`user-name-${user.id}`}>
                      {user.username}
                    </div>
                    <div className="text-xs text-gray-400">
                      ID: {user.id}
                    </div>
                    {user.telegramId && (
                      <div className="text-xs text-blue-400" data-testid={`user-telegram-${user.id}`}>
                        Telegram: {user.telegramId}
                      </div>
                    )}
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-semibold text-primary">
                      Level {user.level}
                    </div>
                    <div className="text-xs text-gray-400">
                      {user.totalAds} ads
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="bg-gray-800/50 p-2 rounded">
                    <div className="text-xs text-success" data-testid={`user-earned-${user.id}`}>
                      ${parseFloat(user.totalEarned).toFixed(3)}
                    </div>
                    <div className="text-xs text-gray-500">Earned</div>
                  </div>
                  <div className="bg-gray-800/50 p-2 rounded">
                    <div className="text-xs text-warning" data-testid={`user-balance-${user.id}`}>
                      ${parseFloat(user.withdrawBalance).toFixed(3)}
                    </div>
                    <div className="text-xs text-gray-500">Balance</div>
                  </div>
                  <div className="bg-gray-800/50 p-2 rounded">
                    <div className="text-xs text-info" data-testid={`user-referrals-${user.id}`}>
                      {user.referralsCount}
                    </div>
                    <div className="text-xs text-gray-500">Referrals</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Withdrawals Tab */}
      {activeTab === 'withdrawals' && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-white">Withdrawal Requests</h3>
          <div className="bg-card p-6 rounded-xl border border-border text-center">
            <div className="text-4xl mb-2">💳</div>
            <div className="text-gray-400">No withdrawal requests at the moment</div>
            <div className="text-sm text-gray-500 mt-2">
              Users need $1.00, 10,000 ads, and 3 referrals to withdraw
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Admin;