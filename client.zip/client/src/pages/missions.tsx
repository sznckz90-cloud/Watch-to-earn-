import { useUserMissions } from "@/hooks/use-user-data";
import type { Mission } from "@shared/schema";

export default function Missions() {
  const { data: missions = [], isLoading } = useUserMissions() as { data: (Mission & { progress: number; completed: boolean; completedAt: Date | null })[]; isLoading: boolean };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin text-primary text-2xl">
          <i className="fas fa-spinner"></i>
        </div>
      </div>
    );
  }

  const getMissionIcon = (type: string) => {
    switch (type) {
      case "daily_checkin":
        return "fas fa-calendar-day text-primary";
      case "watch_ads":
        return "fas fa-play text-warning";
      case "invite_friends":
        return "fas fa-users text-purple-400";
      case "level_up":
        return "fas fa-arrow-up text-blue-400";
      default:
        return "fas fa-star text-primary";
    }
  };

  const getMissionColor = (type: string) => {
    switch (type) {
      case "daily_checkin":
        return "bg-primary/20";
      case "watch_ads":
        return "bg-warning/20";
      case "invite_friends":
        return "bg-purple-500/20";
      case "level_up":
        return "bg-blue-500/20";
      default:
        return "bg-primary/20";
    }
  };

  const getProgressBarColor = (type: string) => {
    switch (type) {
      case "daily_checkin":
        return "bg-primary";
      case "watch_ads":
        return "bg-warning";
      case "invite_friends":
        return "bg-purple-500";
      case "level_up":
        return "bg-blue-500";
      default:
        return "bg-primary";
    }
  };

  return (
    <div className="p-4 pb-20">
      <h2 className="text-2xl font-bold mb-6">Missions</h2>
      
      <div className="space-y-4">
        {missions.map((mission) => {
          const progressPercentage = (mission.progress / mission.target) * 100;
          
          return (
            <div
              key={mission.id}
              className={`bg-card p-5 rounded-xl border border-border hover:border-primary/50 transition-colors cursor-pointer ${
                mission.completed ? "opacity-60" : ""
              }`}
            >
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center space-x-3">
                  <div className={`w-12 h-12 ${getMissionColor(mission.type)} rounded-xl flex items-center justify-center`}>
                    <i className={getMissionIcon(mission.type)}></i>
                  </div>
                  <div>
                    <h3 className="font-semibold">{mission.title}</h3>
                    <p className="text-sm text-gray-400">{mission.description}</p>
                  </div>
                </div>
                <div className="text-success font-bold">+${parseFloat(mission.reward).toFixed(3)}</div>
              </div>
              <div className="w-full bg-gray-800 rounded-full h-2">
                <div
                  className={`${getProgressBarColor(mission.type)} h-2 rounded-full transition-all`}
                  style={{ width: `${Math.min(progressPercentage, 100)}%` }}
                ></div>
              </div>
              <div className="text-xs text-gray-400 mt-2">
                {mission.completed ? "Completed" : `${mission.progress}/${mission.target} completed`}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
