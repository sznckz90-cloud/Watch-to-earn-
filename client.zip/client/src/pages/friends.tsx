import { useState } from "react";
import { useUserData, useUserReferrals } from "@/hooks/use-user-data";
import ToastNotification from "@/components/ui/toast-notification";
import type { User } from "@shared/schema";

export default function Friends() {
  const { data: user } = useUserData();
  const { data: referrals = [] } = useUserReferrals() as { data: User[] };
  
  const [toastState, setToastState] = useState<{
    show: boolean;
    title: string;
    message: string;
    type: "success" | "error" | "info" | "warning";
  }>({
    show: false,
    title: "",
    message: "",
    type: "info",
  });

  const showToast = (title: string, message: string, type: "success" | "error" | "info" | "warning" = "info") => {
    setToastState({ show: true, title, message, type });
  };

  const copyReferralLink = async () => {
    // Get Telegram user ID for referral link
    const tg = (window as any).Telegram?.WebApp?.initDataUnsafe;
    const userId = tg?.user?.id || 'demo-user-123';
    
    // Generate referral link using @LightningSatsbot
    const referralLink = `https://t.me/LightningSatsbot?start=${userId}`;
    
    try {
      await navigator.clipboard.writeText(referralLink);
      showToast("Link Copied!", "Referral link copied to clipboard", "success");
    } catch (error) {
      showToast("Copy Failed", "Please copy the link manually", "error");
    }
  };

  return (
    <div className="p-4 pb-20">
      <h2 className="text-2xl font-bold mb-6">Invite Friends</h2>
      
      {/* Referral Link Card */}
      <div className="bg-gradient-to-br from-card to-gray-900 p-6 rounded-2xl border border-border text-center mb-6">
        <i className="fas fa-user-plus text-primary text-2xl mb-3"></i>
        <h3 className="font-bold text-lg mb-2">Invite Friends</h3>
        <div className="text-sm font-medium text-primary mb-4 break-all">
          t.me/LightningSatsbot?start={(()=> {
            const tg = (window as any).Telegram?.WebApp?.initDataUnsafe;
            return tg?.user?.id || 'demo-user-123';
          })()}
        </div>
        <button
          onClick={copyReferralLink}
          className="bg-primary hover:bg-primary-dark text-white font-semibold py-3 px-6 rounded-xl transition-colors w-full"
        >
          <i className="fas fa-copy mr-2"></i>Copy Referral Link
        </button>
        <p className="text-xs text-gray-400 mt-3">Earn {user?.level === 2 ? '14%' : '10%'} from your invitee's ad income</p>
      </div>

      {/* Referral Stats */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <div className="bg-card p-4 rounded-xl border border-border text-center">
          <div className="text-xl font-bold text-primary">{user?.referralsCount || 0}</div>
          <div className="text-sm text-gray-400">Friends Invited</div>
        </div>
        <div className="bg-card p-4 rounded-xl border border-border text-center">
          <div className="text-xl font-bold text-success">
            ${parseFloat(user?.referralEarnings || "0").toFixed(3)}
          </div>
          <div className="text-sm text-gray-400">Referral Earnings</div>
        </div>
        <div className="bg-card p-4 rounded-xl border border-border text-center">
          <div className="text-xl font-bold text-warning">{user?.level === 2 ? '14%' : '10%'}</div>
          <div className="text-sm text-gray-400">Bonus Rate</div>
        </div>
      </div>

      {/* Friends List */}
      <div className="space-y-3">
        {referrals.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <i className="fas fa-users text-4xl mb-4"></i>
            <p>No friends invited yet</p>
            <p className="text-sm">Share your code to start earning!</p>
          </div>
        ) : (
          referrals.map((friend) => (
            <div
              key={friend.id}
              className="flex items-center justify-between bg-card p-4 rounded-xl border border-border"
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                  <i className="fas fa-user text-white text-sm"></i>
                </div>
                <div>
                  <div className="font-semibold">{friend.username}</div>
                  <div className="text-sm text-gray-400">
                    Joined {new Date(friend.createdAt).toLocaleDateString()}
                  </div>
                </div>
              </div>
              <div className="text-success font-semibold">+$0.001</div>
            </div>
          ))
        )}
      </div>

      <ToastNotification
        {...toastState}
        onClose={() => setToastState(prev => ({ ...prev, show: false }))}
      />
    </div>
  );
}
