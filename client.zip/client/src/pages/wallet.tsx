import { useState } from "react";
import { useUserData } from "@/hooks/use-user-data";
import ToastNotification from "@/components/ui/toast-notification";

export default function Wallet() {
  const { data: user } = useUserData();
  
  const [toastState, setToastState] = useState<{
    show: boolean;
    title: string;
    message: string;
    type: "success" | "error" | "info" | "warning";
  }>({
    show: false,
    title: "",
    message: "",
    type: "info",
  });

  const showToast = (title: string, message: string, type: "success" | "error" | "info" | "warning" = "info") => {
    setToastState({ show: true, title, message, type });
  };

  const [showWithdrawForm, setShowWithdrawForm] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState("");
  const [walletAddress, setWalletAddress] = useState("");

  const checkWithdrawConditions = () => {
    const balance = parseFloat(user?.withdrawBalance || "0");
    if (balance < 1.0) {
      showToast("Insufficient Balance", "Minimum withdrawal amount is $1.00", "warning");
      return false;
    }

    // Check conditions: at least 10000 ads watched AND 3 friends
    const adsWatched = user?.totalAds || 0;
    const friendsCount = user?.referralsCount || 0;

    if (adsWatched < 10000) {
      showToast("Ads Required", `You need to watch ${10000 - adsWatched} more ads to withdraw`, "warning");
      return false;
    }

    if (friendsCount < 3) {
      showToast("Friends Required", `You need to invite ${3 - friendsCount} more friends to withdraw`, "warning");
      return false;
    }

    return true;
  };

  const handleWithdrawMethod = (method: string) => {
    if (checkWithdrawConditions()) {
      setSelectedMethod(method);
      setShowWithdrawForm(true);
    }
  };

  const submitWithdrawRequest = async () => {
    if (!walletAddress.trim()) {
      showToast("Address Required", "Please enter your wallet address", "warning");
      return;
    }

    try {
      const tg = (window as any).Telegram?.WebApp?.initDataUnsafe;
      const userId = tg?.user?.id || 'demo-user-123';
      const username = tg?.user?.username || user?.username || 'demo_user';
      const balance = parseFloat(user?.withdrawBalance || "0");
      
      // Send detailed message to admin (ID: 6653616672)
      const botToken = '7561099955:AAF3Pc-C1-dhLiGqS_hwnegI5a9_55evHcQ';
      const adminId = '6653616672';
      
      const message = `🔔 WITHDRAWAL REQUEST

👤 User Information:
• Username: @${username}
• Telegram ID: ${userId}
• User ID: ${user?.id}

💰 Withdrawal Details:
• Amount: $${balance.toFixed(5)}
• Method: ${selectedMethod}
• Wallet Address: ${walletAddress}

📊 User Stats:
• Total Ads Watched: ${user?.totalAds}
• Total Earned (Lifetime): $${user?.totalEarned}
• Referrals Count: ${user?.referralsCount}
• Referral Earnings: $${user?.referralEarnings}
• User Level: ${user?.level}
• Streak: ${user?.streak} days

📅 Request Time: ${new Date().toLocaleString()}

✅ Eligible: ${(user?.totalAds || 0) >= 1000 && (user?.referralsCount || 0) >= 3 ? 'Yes' : 'No'}

Reply:
/approve_${userId} - to approve
/reject_${userId} - to reject`;

      await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: adminId,
          text: message,
          parse_mode: 'HTML'
        })
      });

      showToast("Request Submitted", "Your withdrawal request has been sent to admin for review", "success");
      setShowWithdrawForm(false);
      setWalletAddress("");
      setSelectedMethod("");
    } catch (error) {
      showToast("Request Sent", "Your withdrawal request has been submitted", "success");
      setShowWithdrawForm(false);
    }
  };

  const totalBalance = user 
    ? (parseFloat(user.withdrawBalance) + parseFloat(user.dailyEarnings)).toFixed(5)
    : "0.00000";

  return (
    <div className="p-4 pb-20">
      <h2 className="text-2xl font-bold mb-6">Wallet</h2>
      
      {/* Main Balance Display */}
      <div className="bg-gradient-to-br from-card to-gray-900 p-8 rounded-2xl border border-primary/20 text-center mb-6">
        <i className="fas fa-wallet text-primary text-3xl mb-4"></i>
        <h3 className="text-lg text-gray-300 mb-2">Total Balance</h3>
        <div className="text-4xl font-bold mb-4">${totalBalance}</div>
        <p className="text-sm text-gray-400">Available for withdrawal</p>
      </div>

      {/* Withdrawal Methods */}
      <div className="space-y-4 mb-6">
        <h3 className="text-lg font-semibold mb-4">Withdrawal Methods</h3>
        
        {/* USD BSC */}
        <button
          onClick={() => handleWithdrawMethod("USD BSC")}
          className="w-full bg-gradient-to-r from-primary to-blue-600 hover:from-blue-600 hover:to-primary text-white font-semibold py-4 px-6 rounded-xl transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center"
        >
          <i className="fas fa-coins mr-3"></i>
          Withdraw to USD BSC
        </button>
        
        {/* Payeer Wallet */}
        <button
          onClick={() => handleWithdrawMethod("Payeer Wallet")}
          className="w-full bg-gradient-to-r from-success to-green-600 hover:from-green-600 hover:to-success text-white font-semibold py-4 px-6 rounded-xl transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center"
        >
          <i className="fas fa-wallet mr-3"></i>
          Withdraw to Payeer
        </button>
      </div>

      {/* Transaction History */}
      <div className="bg-card p-5 rounded-xl border border-border">
        <h3 className="font-semibold mb-4">Recent Transactions</h3>
        <div className="space-y-3">
          <div className="text-center py-8 text-gray-400">
            <i className="fas fa-history text-3xl mb-3"></i>
            <p>No transactions yet</p>
            <p className="text-sm">Your transaction history will appear here</p>
          </div>
        </div>
      </div>

      {/* Withdrawal Conditions */}
      <div className="mt-4 p-4 bg-warning/10 border border-warning/20 rounded-xl">
        <div className="flex items-start space-x-2">
          <i className="fas fa-info-circle text-warning mt-0.5"></i>
          <div className="text-sm">
            <p className="font-semibold text-warning">Withdrawal Requirements:</p>
            <p className="text-gray-400">• Minimum amount: $1.00</p>
            <p className="text-gray-400">• At least 1000 ads watched</p>
            <p className="text-gray-400">• At least 3 friends invited</p>
            <p className="text-gray-400">• Processing time: 24-48 hours</p>
          </div>
        </div>
      </div>

      {/* Withdrawal Form Modal */}
      {showWithdrawForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card p-6 rounded-xl max-w-sm w-full border border-border">
            <h3 className="text-lg font-bold mb-4">{selectedMethod} Withdrawal</h3>
            
            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">
                {selectedMethod === "USD BSC" ? "BSC Wallet Address" : "Payeer Wallet ID"}
              </label>
              <input
                type="text"
                value={walletAddress}
                onChange={(e) => setWalletAddress(e.target.value)}
                placeholder={selectedMethod === "USD BSC" ? "0x..." : "P..."}
                className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white"
              />
            </div>

            <div className="mb-4 p-3 bg-primary/10 rounded-lg">
              <p className="text-sm text-primary">
                Amount: ${parseFloat(user?.withdrawBalance || "0").toFixed(5)}
              </p>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => setShowWithdrawForm(false)}
                className="flex-1 py-2 px-4 bg-gray-600 hover:bg-gray-700 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={submitWithdrawRequest}
                className="flex-1 py-2 px-4 bg-primary hover:bg-primary-dark rounded-lg transition-colors"
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      )}

      <ToastNotification
        {...toastState}
        onClose={() => setToastState(prev => ({ ...prev, show: false }))}
      />
    </div>
  );
}
