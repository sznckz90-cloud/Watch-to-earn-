import { useState, useEffect } from "react";
import { useUserData, useWatchAd, useClaimEarnings } from "@/hooks/use-user-data";
import ToastNotification from "@/components/ui/toast-notification";
import LoadingOverlay from "@/components/ui/loading-overlay";
import { useToast } from "@/hooks/use-toast";
import { getRewardPerAd, getDailyLimit, checkLevelUp, getAdsRequiredForNextLevel } from "@/utils/rewardLogic";
import { getAdViewsToday, incrementAdView, addEarnings } from "@/utils/userProgress";

export default function Home() {
  const { data: user, isLoading } = useUserData();
  const watchAdMutation = useWatchAd();
  const claimEarningsMutation = useClaimEarnings();
  const { toast } = useToast();
  
  // Telegram WebApp integration
  useEffect(() => {
    if (typeof window !== 'undefined' && (window as any).Telegram?.WebApp) {
      const tg = (window as any).Telegram.WebApp;
      tg.ready();
      
      // Get Telegram user info
      if (tg.initDataUnsafe?.user?.id && user && !user.telegramId) {
        // Update user with Telegram ID if not already set
        const telegramId = tg.initDataUnsafe.user.id.toString();
        console.log('Telegram user detected:', telegramId);
        
        // You can add an API call here to update the user's Telegram ID
        fetch(`/api/users/${user.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ telegramId })
        }).catch(console.error);
      }
    }
  }, [user]);
  
  const [toastState, setToastState] = useState<{
    show: boolean;
    title: string;
    message: string;
    type: "success" | "error" | "info" | "warning";
  }>({
    show: false,
    title: "",
    message: "",
    type: "info",
  });

  const showToast = (title: string, message: string, type: "success" | "error" | "info" | "warning" = "info") => {
    setToastState({ show: true, title, message, type });
  };

  const [showLevelModal, setShowLevelModal] = useState(false);

  // Level-based configurations
  const getLevelConfig = (level: number) => {
    switch (level) {
      case 1:
        return {
          earnings: "0.0003",
          dailyLimit: 100,
          referralBonus: 10
        };
      case 2:
        return {
          earnings: "0.0006", 
          dailyLimit: 150,
          referralBonus: 14
        };
      default:
        return {
          earnings: "0.0003",
          dailyLimit: 100, 
          referralBonus: 10
        };
    }
  };

  const currentLevelConfig = getLevelConfig(user?.level || 1);

  // Setup MonetAg libtl.com SDK with better error handling
  useEffect(() => {
    const initializeMonetAg = () => {
      try {
        const existingScript = document.querySelector("script[src*='libtl.com/sdk.js']");
        if (!existingScript) {
          const script = document.createElement('script');
          script.src = '//libtl.com/sdk.js';
          script.setAttribute('data-zone', '9368336');
          script.setAttribute('data-sdk', 'show_9368336');
          script.setAttribute('data-cfasync', 'false');
          script.async = true;
          
          script.onload = () => {
            console.log('MonetAg SDK loaded successfully');
            setTimeout(() => {
              if (typeof (window as any).show_9368336 === 'function') {
                console.log('MonetAg ads ready!');
              }
            }, 2000);
          };
          
          script.onerror = () => {
            console.warn('MonetAg SDK failed to load');
          };
          
          document.head.appendChild(script);
          console.log('MonetAg SDK injected.');
        } else {
          console.log('MonetAg SDK already present.');
        }
      } catch (error) {
        console.error('Failed to initialize MonetAg:', error);
      }
    };

    initializeMonetAg();
  }, []);

  // Check ad readiness with timeout protection
  const isAdReady = () => {
    return typeof (window as any).show_9368336 === 'function';
  };

  // Safe ad execution with timeout
  const executeAdWithTimeout = async (adType: string = 'default', timeout: number = 15000): Promise<boolean> => {
    return new Promise((resolve) => {
      if (!isAdReady()) {
        console.warn('MonetAg not ready');
        resolve(false);
        return;
      }

      let completed = false;
      const timeoutId = setTimeout(() => {
        if (!completed) {
          console.warn(`Ad timeout after ${timeout}ms`);
          completed = true;
          resolve(false);
        }
      }, timeout);

      try {
        const adPromise = adType === 'popup' 
          ? (window as any).show_9368336('pop')
          : (window as any).show_9368336();

        if (adPromise && typeof adPromise.then === 'function') {
          adPromise
            .then(() => {
              if (!completed) {
                console.log(`MonetAg ${adType} ad completed!`);
                completed = true;
                clearTimeout(timeoutId);
                resolve(true);
              }
            })
            .catch((error: any) => {
              if (!completed) {
                console.error(`MonetAg ${adType} ad failed:`, error);
                completed = true;
                clearTimeout(timeoutId);
                resolve(false);
              }
            });
        } else {
          // Non-promise response, assume success
          if (!completed) {
            console.log(`MonetAg ${adType} ad executed`);
            completed = true;
            clearTimeout(timeoutId);
            resolve(true);
          }
        }
      } catch (error) {
        if (!completed) {
          console.error(`MonetAg ${adType} execution failed:`, error);
          completed = true;
          clearTimeout(timeoutId);
          resolve(false);
        }
      }
    });
  };

  const handleWatchAd = async () => {
    if (watchAdMutation.isPending) return;
    
    const level = user?.level || 1;
    const adViewsToday = getAdViewsToday();
    const dailyLimit = getDailyLimit(level);
    const rewardAmount = getRewardPerAd(level);
    
    // Check daily limit using utility function
    if (adViewsToday >= dailyLimit) {
      showToast("Daily Limit Reached", `You've reached your daily limit of ${dailyLimit} ads.`, "warning");
      return;
    }
    
    try {
      if (!isAdReady()) {
        showToast("Ads Loading ⏳", "Ad network is still loading. Please wait a moment...", "warning");
        return;
      }

      console.log('Starting MonetAg rewarded ad...');
      showToast("Loading Ad 📺", "Please wait while ad loads...", "info");
      
      // Execute real MonetAg ad with timeout protection
      const adSuccess = await executeAdWithTimeout('default', 20000);
      
      if (adSuccess) {
        // Update local tracking
        incrementAdView();
        const newTotal = addEarnings(rewardAmount);
        
        // Update server
        await watchAdMutation.mutateAsync();
        
        // Check for level up
        const totalAds = (user?.adsWatched || 0) + 1;
        const newLevel = checkLevelUp(totalAds);
        if (newLevel > level) {
          const bonusAmount = newLevel === 2 ? 0.25 : newLevel === 3 ? 0.50 : 0;
          if (bonusAmount > 0) {
            showToast("Level Up! 🎉", `Level ${newLevel} reached! +$${bonusAmount.toFixed(2)} bonus earned!`, "success");
          } else {
            showToast("Level Up! 🎉", `Congratulations! You reached Level ${newLevel}!`, "success");
          }
        } else {
          showToast("Ad Completed! ✅", `You earned $${rewardAmount.toFixed(6)}. Total: $${newTotal.toFixed(6)}`, "success");
        }
      } else {
        showToast("Ad Error ❌", "Ad failed to load or timed out. Please try again.", "error");
        return;
      }
    } catch (error) {
      console.error('Watch ad error:', error);
      showToast("Error", "Something went wrong. Please try again.", "error");
    }
  };

  const handleClaimEarnings = async () => {
    if (claimEarningsMutation.isPending) return;
    
    // Check if user completed daily limit first
    const canClaim = user && user.adsWatched >= user.dailyLimit;
    if (!canClaim) {
      showToast("Complete Daily Ads", "Watch all daily ads first to claim rewards", "warning");
      return;
    }
    
    try {
      if (!isAdReady()) {
        showToast("Ads Loading ⏳", "Ad network is still loading. Please wait a moment...", "warning");
        return;
      }

      console.log('Starting claim process with MonetAg popup...');
      showToast("Loading Claim Ad 📺", "Please wait while claim ad loads...", "info");
      
      // Execute real MonetAg popup ad with timeout protection
      const claimAdSuccess = await executeAdWithTimeout('popup', 15000);
      
      if (claimAdSuccess) {
        console.log('MonetAg claim ad completed successfully!');
        
        // Allow claim after real ad
        await claimEarningsMutation.mutateAsync();
        showToast("Earnings Claimed! 🎊", "Transferred to withdraw balance", "success");
      } else {
        showToast("Ad Required 📺", "Please watch the ad to claim your rewards", "warning");
      }
    } catch (error) {
      console.error('Claim error:', error);
      showToast("Error", "Something went wrong. Please try again.", "error");
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin text-primary text-2xl">
          <i className="fas fa-spinner"></i>
        </div>
      </div>
    );
  }

  const progressPercentage = user ? (user.adsWatched / user.dailyLimit) * 100 : 0;

  return (
    <div className="pb-20">
      {/* Level Info Modal */}
      {showLevelModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card rounded-2xl p-6 max-w-md w-full border border-border">
            <div className="text-center mb-4">
              <div className="text-4xl font-bold text-primary mb-2">Level {user?.level || 1}</div>
              <div className="text-gray-300">Level Benefits</div>
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
                <span className="text-gray-300">Earnings per Ad</span>
                <span className="text-primary font-semibold">${currentLevelConfig.earnings}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
                <span className="text-gray-300">Daily Ad Limit</span>
                <span className="text-success font-semibold">{currentLevelConfig.dailyLimit} ads</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
                <span className="text-gray-300">Referral Bonus</span>
                <span className="text-warning font-semibold">{currentLevelConfig.referralBonus}%</span>
              </div>
              {user?.level === 1 && (
                <div className="mt-4 p-3 bg-primary/10 rounded-lg border border-primary/20">
                  <div className="text-primary font-semibold mb-1">Next Level Progress</div>
                  <div className="text-sm text-gray-300 mb-2">
                    Total Ads: {user?.totalAds || 0} / 10,000 for Level 2
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2 mb-2">
                    <div
                      className="bg-primary h-2 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(((user?.totalAds || 0) / 10000) * 100, 100)}%` }}
                    ></div>
                  </div>
                  <div className="text-xs text-gray-400 mb-2">
                    {10000 - (user?.totalAds || 0)} ads remaining
                  </div>
                  <div className="text-sm text-gray-300">Level 2: $0.0006 per ad, 150 daily ads, 14% referral bonus</div>
                </div>
              )}
              {user?.level === 2 && (
                <div className="mt-4 p-3 bg-primary/10 rounded-lg border border-primary/20">
                  <div className="text-primary font-semibold mb-1">Next Level Progress</div>
                  <div className="text-sm text-gray-300 mb-2">
                    Total Ads: {user?.totalAds || 0} / 50,000 for Level 3
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2 mb-2">
                    <div
                      className="bg-primary h-2 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(((user?.totalAds || 0) / 50000) * 100, 100)}%` }}
                    ></div>
                  </div>
                  <div className="text-xs text-gray-400 mb-2">
                    {50000 - (user?.totalAds || 0)} ads remaining
                  </div>
                  <div className="text-sm text-gray-300">Level 3: $0.0009 per ad, 200 daily ads, 18% referral bonus</div>
                </div>
              )}
            </div>
            <button
              onClick={() => setShowLevelModal(false)}
              className="w-full mt-6 bg-primary hover:bg-primary-dark text-white font-semibold py-3 rounded-xl transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Balance Cards */}
      <div className="p-4 space-y-4">
        {/* Primary Balance Card */}
        <div className="relative bg-gradient-to-br from-card to-gray-900 p-6 rounded-2xl border border-primary/20 overflow-hidden">
          <div className="absolute top-0 right-0 w-20 h-20 bg-primary/10 rounded-full blur-xl"></div>
          <div className="relative z-10">
            <div className="flex items-center space-x-2 mb-2">
              <i className="fas fa-wallet text-primary"></i>
              <span className="text-sm text-gray-300">Withdraw Balance</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-3xl font-bold mb-1">
                  ${parseFloat(user?.withdrawBalance || "0").toFixed(5)}
                </div>
                <p className="text-xs text-gray-400">Available for withdrawal</p>
              </div>
              <button
                onClick={() => setShowLevelModal(true)}
                className="bg-primary/20 hover:bg-primary/30 border border-primary/30 text-primary px-4 py-2 rounded-lg transition-colors flex items-center space-x-2"
                data-testid="button-level-info"
              >
                <i className="fas fa-star"></i>
                <span className="font-semibold">Level {user?.level || 1}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Today's Earnings Card */}
        <div className="bg-card p-5 rounded-xl border border-border">
          <div className="flex items-center space-x-2 mb-2">
            <i className="fas fa-coins text-success"></i>
            <span className="text-sm text-gray-300">Today's Earnings</span>
          </div>
          <div className="text-2xl font-bold text-success mb-1">
            ${parseFloat(user?.dailyEarnings || "0").toFixed(5)}
          </div>
          <p className="text-xs text-gray-400">Earned from watching ads</p>
        </div>
      </div>

      {/* Daily Progress */}
      <div className="px-4 mb-6">
        <div className="flex justify-between items-center mb-3">
          <h3 className="font-semibold text-white">Daily Progress</h3>
          <span className="text-sm text-gray-400">
            {user?.adsWatched || 0}/{user?.dailyLimit || 20}
          </span>
        </div>
        <div className="w-full bg-gray-800 rounded-full h-3 overflow-hidden">
          <div
            className="bg-gradient-to-r from-primary to-success h-full transition-all duration-300 ease-out"
            style={{ width: `${Math.min(progressPercentage, 100)}%` }}
          ></div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="px-4 space-y-3">
        {/* Watch Ad Button */}
        <button
          onClick={handleWatchAd}
          disabled={watchAdMutation.isPending || (user && user.adsWatched >= user.dailyLimit)}
          className="w-full bg-gradient-to-r from-primary to-primary-dark hover:from-primary-dark hover:to-primary text-white font-semibold py-4 px-6 rounded-xl shadow-lg hover:shadow-primary/25 transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center space-x-3 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <i className="fas fa-play text-xl"></i>
          <span className="text-lg">Watch to Earn</span>
          <div className="bg-white/20 px-2 py-1 rounded-full text-sm">+${currentLevelConfig.earnings}</div>
        </button>

        {/* Claim Earnings Button */}
        <button
          onClick={handleClaimEarnings}
          disabled={!user || user.adsWatched < user.dailyLimit || claimEarningsMutation.isPending}
          className="w-full bg-card hover:bg-gray-800 text-gray-300 font-semibold py-4 px-6 rounded-xl border border-border hover:border-primary/50 transition-all duration-200 flex items-center justify-center space-x-3 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <i className="fas fa-gift"></i>
          <span>Claim Daily Earnings</span>
        </button>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-3 mt-6">
          <div className="bg-card p-4 rounded-xl text-center border border-border">
            <div className="text-lg font-bold text-primary">{user?.totalAds || 0}</div>
            <div className="text-xs text-gray-400">Total Ads</div>
          </div>
          <div className="bg-card p-4 rounded-xl text-center border border-border">
            <div className="text-lg font-bold text-success">
              ${parseFloat(user?.totalEarned || "0").toFixed(2)}
            </div>
            <div className="text-xs text-gray-400">Total Earned</div>
          </div>
          <div className="bg-card p-4 rounded-xl text-center border border-border">
            <div className="text-lg font-bold text-warning">{user?.streak || 0}</div>
            <div className="text-xs text-gray-400">Day Streak</div>
          </div>
        </div>
      </div>

      <LoadingOverlay show={watchAdMutation.isPending} />
      <ToastNotification
        {...toastState}
        onClose={() => setToastState(prev => ({ ...prev, show: false }))}
      />
    </div>
  );
}
