import { Link, useLocation } from "wouter";
import { useUserData } from "@/hooks/use-user-data";

const navItems = [
  { path: "/", icon: "fas fa-home", label: "Earn" },
  { path: "/friends", icon: "fas fa-users", label: "Friends" },
  { path: "/missions", icon: "fas fa-trophy", label: "Missions" },
  { path: "/wallet", icon: "fas fa-wallet", label: "Wallet" },
];

export default function BottomNavigation() {
  const [location] = useLocation();
  const { data: user } = useUserData();
  
  // Check if current user is admin
  const isAdmin = user?.telegramId === "6653616672";
  
  // Add admin tab for admin users
  const displayItems = isAdmin 
    ? [...navItems, { path: "/admin", icon: "fas fa-shield-alt", label: "Admin" }]
    : navItems;

  return (
    <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-sm bg-card/80 backdrop-blur-lg border-t border-border z-50">
      <div className="flex justify-around py-3">
        {displayItems.map((item) => {
          const isActive = location === item.path;
          return (
            <Link
              key={item.path}
              href={item.path}
              className={`flex flex-col items-center space-y-1 p-2 rounded-lg transition-colors min-w-[60px] ${
                isActive
                  ? "text-primary bg-primary/10"
                  : "text-gray-400 hover:bg-gray-800"
              }`}
            >
              <i className={`${item.icon} text-lg`}></i>
              <span className="text-xs font-medium">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
