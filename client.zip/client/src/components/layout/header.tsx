import { useUserData } from "@/hooks/use-user-data";

export default function Header() {
  const { data: user } = useUserData();

  return (
    <div className="sticky top-0 z-50 bg-card/80 backdrop-blur-lg border-b border-border px-4 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center justify-center w-full">
          <h1 className="font-bold text-lg text-white">Watch to Earn - Tester Men</h1>
        </div>
      </div>
    </div>
  );
}
