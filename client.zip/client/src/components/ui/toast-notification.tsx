import { useEffect, useState } from "react";

interface ToastProps {
  title: string;
  message: string;
  type?: "success" | "error" | "info" | "warning";
  show: boolean;
  onClose: () => void;
}

export default function ToastNotification({ title, message, type = "info", show, onClose }: ToastProps) {
  useEffect(() => {
    if (show) {
      const timer = setTimeout(() => {
        onClose();
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [show, onClose]);

  const icons = {
    success: "fas fa-check-circle text-success",
    error: "fas fa-exclamation-circle text-red-500",
    info: "fas fa-info-circle text-primary",
    warning: "fas fa-exclamation-triangle text-warning",
  };

  return (
    <div
      className={`fixed top-4 right-4 bg-card border border-border rounded-xl p-4 max-w-sm transform transition-transform duration-300 z-50 ${
        show ? "translate-x-0" : "translate-x-full"
      }`}
    >
      <div className="flex items-start space-x-3">
        <div>
          <i className={`${icons[type]} text-xl`}></i>
        </div>
        <div>
          <div className="font-semibold text-white">{title}</div>
          <div className="text-sm text-gray-400 mt-1">{message}</div>
        </div>
      </div>
    </div>
  );
}
