interface LoadingOverlayProps {
  show: boolean;
}

export default function LoadingOverlay({ show }: LoadingOverlayProps) {
  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center">
      <div className="bg-card p-6 rounded-xl border border-border text-center">
        <div className="animate-spin-slow text-primary text-3xl mb-4">
          <i className="fas fa-play"></i>
        </div>
        <p className="font-semibold">Loading Ad...</p>
        <p className="text-sm text-gray-400 mt-1">Please wait</p>
      </div>
    </div>
  );
}
