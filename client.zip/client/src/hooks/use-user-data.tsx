import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { User } from "@shared/schema";

const CURRENT_USER_ID = "demo-user-123"; // In real app, this would come from auth

export function useUserData() {
  return useQuery<User>({
    queryKey: ["/api/users", CURRENT_USER_ID],
  });
}

export function useWatchAd() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/ads/watch", {
        userId: CURRENT_USER_ID,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", CURRENT_USER_ID] });
      queryClient.invalidateQueries({ queryKey: ["/api/users", CURRENT_USER_ID, "missions"] });
    },
  });
}

export function useUserMissions() {
  return useQuery({
    queryKey: ["/api/users", CURRENT_USER_ID, "missions"],
  });
}

export function useClaimEarnings() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/users/${CURRENT_USER_ID}/claim`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", CURRENT_USER_ID] });
    },
  });
}

export function useUserReferrals() {
  return useQuery({
    queryKey: ["/api/users", CURRENT_USER_ID, "referrals"],
  });
}

export function useRegisterUser() {
  return useMutation({
    mutationFn: async (userData: { username: string; referralCode?: string }) => {
      const response = await apiRequest("POST", "/api/users/register", userData);
      return response.json();
    },
  });
}

export const getCurrentUserId = () => CURRENT_USER_ID;
