export const getUserLevel = (): number => {
  return parseInt(localStorage.getItem('userLevel') || '1');
};

export const setUserLevel = (level: number) => {
  localStorage.setItem('userLevel', level.toString());
};

export const getAdViewsToday = (): number => {
  const today = new Date().toISOString().split('T')[0];
  const data = JSON.parse(localStorage.getItem('adViews') || '{}');
  return data[today] || 0;
};

export const incrementAdView = () => {
  const today = new Date().toISOString().split('T')[0];
  const data = JSON.parse(localStorage.getItem('adViews') || '{}');
  data[today] = (data[today] || 0) + 1;
  localStorage.setItem('adViews', JSON.stringify(data));
};

export const getTotalEarnings = (): number => {
  return parseFloat(localStorage.getItem('totalEarned') || '0');
};

export const addEarnings = (amount: number) => {
  const current = getTotalEarnings();
  const newTotal = current + amount;
  localStorage.setItem('totalEarned', newTotal.toFixed(6));
  return newTotal;
};