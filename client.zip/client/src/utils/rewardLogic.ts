export const getRewardPerAd = (level: number): number => {
  if (level === 1) return 0.0003;
  if (level === 2) return 0.0006;
  if (level === 3) return 0.0009;
  return 0.0003; // default
};

export const getDailyLimit = (level: number): number => {
  if (level === 1) return 100;
  if (level === 2) return 150;
  if (level === 3) return 200;
  return 100; // default
};

export const getReferralBonus = (level: number): number => {
  if (level === 1) return 0.10; // 10%
  if (level === 2) return 0.14; // 14%
  if (level === 3) return 0.18; // 18%
  return 0.10; // default
};

export const checkLevelUp = (totalAds: number): number => {
  if (totalAds >= 50000) return 3; // Level 3 at 50,000 total ads
  if (totalAds >= 10000) return 2; // Level 2 at 10,000 total ads
  return 1; // Level 1
};

export const getAdsRequiredForNextLevel = (currentLevel: number): number => {
  if (currentLevel === 1) return 10000;
  if (currentLevel === 2) return 50000;
  return 0; // Max level reached
};