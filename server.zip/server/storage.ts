import { type User, type InsertUser, type AdSession, type InsertAdSession, type Mission, type UserMission, type InsertUserMission } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByReferralCode(referralCode: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User>;
  getUserReferrals(userId: string): Promise<User[]>;

  // Ad session operations
  createAdSession(adSession: InsertAdSession): Promise<AdSession>;
  getUserAdSessions(userId: string): Promise<AdSession[]>;

  // Mission operations
  getAllMissions(): Promise<Mission[]>;
  getMission(id: string): Promise<Mission | undefined>;
  getUserMissions(userId: string): Promise<UserMission[]>;
  getUserMission(userId: string, missionId: string): Promise<UserMission | undefined>;
  createUserMission(userMission: InsertUserMission): Promise<UserMission>;
  updateUserMission(id: string, updates: Partial<UserMission>): Promise<UserMission>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private adSessions: Map<string, AdSession>;
  private missions: Map<string, Mission>;
  private userMissions: Map<string, UserMission>;

  constructor() {
    this.users = new Map();
    this.adSessions = new Map();
    this.missions = new Map();
    this.userMissions = new Map();
    
    // Initialize default missions
    this.initializeMissions();
    // Initialize demo user
    this.initializeDemoUser();
  }

  private initializeMissions() {
    const defaultMissions = [
      {
        id: "daily-checkin",
        title: "Daily Check-in",
        description: "Visit the app daily",
        reward: "0.001",
        type: "daily_checkin",
        target: 1,
        isActive: true,
      },
      {
        id: "watch-100-ads",
        title: "Watch 100 Ads",
        description: "Complete 100 ad views today",
        reward: "0.001",
        type: "watch_ads",
        target: 100,
        isActive: true,
      },
      {
        id: "invite-5-friends",
        title: "Invite 5 Friends",
        description: "Get friends to join with your code",
        reward: "0.05",
        type: "invite_friends",
        target: 5,
        isActive: true,
      },
      {
        id: "reach-level-2",
        title: "Reach Level 2",
        description: "Watch 10,000 ads to level up",
        reward: "0.25",
        type: "level_up",
        target: 10000,
        isActive: true,
      },
    ];

    defaultMissions.forEach(mission => {
      this.missions.set(mission.id, mission as Mission);
    });
  }

  private async initializeDemoUser() {
    const demoUser: User = {
      id: "demo-user-123",
      username: "demo_user",
      referralCode: "ADEARN123",
      referredBy: null,
      telegramId: "6653616672", // Admin Telegram ID
      withdrawBalance: "0.00050",
      dailyEarnings: "0.00024",
      adsWatched: 6,
      dailyLimit: 100, // Level 1 daily limit
      level: 1,
      totalAds: 15,
      totalEarned: "0.00600",
      streak: 2,
      referralsCount: 0,
      referralEarnings: "0.00000",
      lastAdWatch: new Date(),
      lastClaimDate: null,
      createdAt: new Date(),
    };
    this.users.set(demoUser.id, demoUser);

    // Initialize user missions for demo user
    const missions = Array.from(this.missions.values());
    for (const mission of missions) {
      const userMission: UserMission = {
        id: randomUUID(),
        userId: demoUser.id,
        missionId: mission.id,
        progress: mission.type === "watch_ads" ? 6 : mission.type === "daily_checkin" ? 1 : 0,
        completed: false,
        completedAt: null,
      };
      this.userMissions.set(userMission.id, userMission);
    }
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByReferralCode(referralCode: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.referralCode === referralCode,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      referredBy: insertUser.referredBy || null,
      telegramId: insertUser.telegramId || null,
      withdrawBalance: "0.00000",
      dailyEarnings: "0.00000",
      adsWatched: 0,
      dailyLimit: 100, // Level 1 daily limit
      level: 1,
      totalAds: 0,
      totalEarned: "0.00000",
      streak: 0,
      referralsCount: 0,
      referralEarnings: "0.00000",
      lastAdWatch: null,
      lastClaimDate: null,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getUserReferrals(userId: string): Promise<User[]> {
    const user = this.users.get(userId);
    if (!user) return [];
    
    return Array.from(this.users.values()).filter(
      (u) => u.referredBy === user.referralCode
    );
  }

  async createAdSession(insertAdSession: InsertAdSession): Promise<AdSession> {
    const id = randomUUID();
    const adSession: AdSession = {
      ...insertAdSession,
      id,
      completedAt: new Date(),
    };
    this.adSessions.set(id, adSession);
    return adSession;
  }

  async getUserAdSessions(userId: string): Promise<AdSession[]> {
    return Array.from(this.adSessions.values()).filter(
      (session) => session.userId === userId
    );
  }

  async getAllMissions(): Promise<Mission[]> {
    return Array.from(this.missions.values()).filter(m => m.isActive);
  }

  async getMission(id: string): Promise<Mission | undefined> {
    return this.missions.get(id);
  }

  async getUserMissions(userId: string): Promise<UserMission[]> {
    return Array.from(this.userMissions.values()).filter(
      (um) => um.userId === userId
    );
  }

  async getUserMission(userId: string, missionId: string): Promise<UserMission | undefined> {
    return Array.from(this.userMissions.values()).find(
      (um) => um.userId === userId && um.missionId === missionId
    );
  }

  async createUserMission(insertUserMission: InsertUserMission): Promise<UserMission> {
    const id = randomUUID();
    const userMission: UserMission = {
      ...insertUserMission,
      id,
      progress: 0,
      completed: false,
      completedAt: null,
    };
    this.userMissions.set(id, userMission);
    return userMission;
  }

  async updateUserMission(id: string, updates: Partial<UserMission>): Promise<UserMission> {
    const userMission = this.userMissions.get(id);
    if (!userMission) {
      throw new Error("User mission not found");
    }
    const updatedUserMission = { ...userMission, ...updates };
    this.userMissions.set(id, updatedUserMission);
    return updatedUserMission;
  }

  // Admin methods
  async getAdminStats(): Promise<{
    totalUsers: number;
    totalAds: number;
    totalEarnings: string;
    activeUsers: number;
  }> {
    const users = Array.from(this.users.values());
    const totalUsers = users.length;
    const totalAds = users.reduce((sum, user) => sum + user.totalAds, 0);
    const totalEarnings = users.reduce((sum, user) => sum + parseFloat(user.totalEarned), 0).toFixed(5);
    
    // Active users are those who watched ads in the last 24 hours
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const activeUsers = users.filter(user => 
      user.lastAdWatch && user.lastAdWatch > oneDayAgo
    ).length;

    return {
      totalUsers,
      totalAds,
      totalEarnings,
      activeUsers
    };
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }
}

export const storage = new MemStorage();
