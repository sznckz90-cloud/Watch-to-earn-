// Telegram Bot API Service
const BOT_TOKEN = '7561099955:AAF3Pc-C1-dhLiGqS_hwnegI5a9_55evHcQ';

interface TelegramMessage {
  chatId: number | string;
  text: string;
  parseMode?: 'HTML' | 'Markdown';
}

export const sendTelegramMessage = async (chatId: number | string, messageText: string): Promise<boolean> => {
  const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: messageText,
        parse_mode: 'HTML'
      }),
    });

    const data = await res.json();
    if (data.ok) {
      console.log('✅ Telegram message sent successfully');
      return true;
    } else {
      console.error('❌ Telegram API error:', data.description);
      return false;
    }
  } catch (err) {
    console.error('❌ Telegram fetch error:', err);
    return false;
  }
};

// Notification templates
export const TelegramNotifications = {
  // Ad watching reward
  adReward: (amount: string) => 
    `🎉 <b>Lightning Sats Reward!</b>\n\n💰 You earned <b>$${amount}</b> for watching an ad!\n\n⚡ Keep watching to earn more!`,

  // Level up notification
  levelUp: (newLevel: number) => 
    `🎉 <b>LEVEL UP!</b>\n\n🚀 Congratulations! You reached <b>Level ${newLevel}</b>!\n\n💰 Higher earnings per ad\n📈 Increased daily limits\n🎁 Better referral bonuses`,

  // Daily limit reached
  dailyLimitReached: (limit: number, amount: string) => 
    `⏰ <b>Daily Limit Reached!</b>\n\n📺 You've watched ${limit} ads today\n💰 Total earned: <b>$${amount}</b>\n\n🔄 Come back tomorrow for more earning opportunities!`,

  // Referral bonus
  referralBonus: (amount: string, referralUsername: string) => 
    `👥 <b>Referral Bonus!</b>\n\n💰 You earned <b>$${amount}</b> from @${referralUsername}'s ad activity!\n\n🎁 Keep inviting friends to earn more bonuses!`,

  // Withdrawal request
  withdrawalRequest: (amount: string, method: string) => 
    `💸 <b>Withdrawal Request</b>\n\n💰 Amount: <b>$${amount}</b>\n🏦 Method: <b>${method}</b>\n\n⏳ Your withdrawal is being processed. You'll receive it within 24-48 hours.`,

  // Mission completed
  missionCompleted: (missionTitle: string, reward: string) => 
    `🎯 <b>Mission Completed!</b>\n\n✅ <b>${missionTitle}</b>\n💰 Reward: <b>$${reward}</b>\n\n🎉 Great job! Check for new missions.`,

  // Level up bonus
  levelUpBonus: (bonusAmount: string) => 
    `🎁 <b>Level Up Bonus!</b>\n\n💰 You received a <b>$${bonusAmount}</b> bonus for reaching the new level!\n\n🚀 This has been added to your withdraw balance!`,

  // Welcome message
  welcome: (username: string, referralCode: string) => 
    `⚡ <b>Welcome to Lightning Sats!</b>\n\n👤 Username: @${username}\n🔗 Your referral code: <b>${referralCode}</b>\n\n💰 Start watching ads to earn cryptocurrency!\n👥 Share your referral code to earn bonuses!`,
};

// Send notification with error handling
export const sendNotification = async (chatId: number | string, notificationType: string, ...params: any[]): Promise<void> => {
  try {
    let message = '';
    
    switch (notificationType) {
      case 'adReward':
        message = TelegramNotifications.adReward(params[0]);
        break;
      case 'levelUp':
        message = TelegramNotifications.levelUp(params[0]);
        break;
      case 'dailyLimitReached':
        message = TelegramNotifications.dailyLimitReached(params[0], params[1]);
        break;
      case 'referralBonus':
        message = TelegramNotifications.referralBonus(params[0], params[1]);
        break;
      case 'withdrawalRequest':
        message = TelegramNotifications.withdrawalRequest(params[0], params[1]);
        break;
      case 'missionCompleted':
        message = TelegramNotifications.missionCompleted(params[0], params[1]);
        break;
      case 'welcome':
        message = TelegramNotifications.welcome(params[0], params[1]);
        break;
      case 'levelUpBonus':
        message = TelegramNotifications.levelUpBonus(params[0]);
        break;
      default:
        console.log('Unknown notification type:', notificationType);
        return;
    }

    await sendTelegramMessage(chatId, message);
  } catch (error) {
    console.error('Error sending Telegram notification:', error);
  }
};