import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema } from "@shared/schema";
import { z } from "zod";
import fetch from "node-fetch";
import { sendNotification } from "./telegram";

export async function registerRoutes(app: Express): Promise<Server> {
  // User registration/login
  app.post("/api/users/register", async (req, res) => {
    try {
      const { username, referralCode: referredBy } = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Generate unique referral code
      const referralCode = `ADEARN${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
      
      const user = await storage.createUser({
        username,
        referralCode,
        referredBy: referredBy || null,
      });

      // Initialize user missions
      const missions = await storage.getAllMissions();
      for (const mission of missions) {
        await storage.createUserMission({
          userId: user.id,
          missionId: mission.id,
        });
      }

      // If user was referred, update referrer's stats with level-based bonus
      if (referredBy) {
        const referrer = await storage.getUserByReferralCode(referredBy);
        if (referrer) {
          const referrerLevelConfig = getLevelConfig(referrer.level);
          const referralBonus = 0.001 * (referrerLevelConfig.referralBonus / 10); // Base 0.001 * bonus percentage
          await storage.updateUser(referrer.id, {
            referralsCount: referrer.referralsCount + 1,
            referralEarnings: (parseFloat(referrer.referralEarnings) + referralBonus).toFixed(5),
          });
        }
      }

      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Get user data
  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Update user data (for Telegram ID updates)
  app.patch("/api/users/:id", async (req, res) => {
    try {
      const updates = req.body;
      const updatedUser = await storage.updateUser(req.params.id, updates);
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Level-based configuration helper
  const getLevelConfig = (level: number) => {
    switch (level) {
      case 1:
        return {
          earnings: 0.0003,
          dailyLimit: 100,
          referralBonus: 10
        };
      case 2:
        return {
          earnings: 0.0006, 
          dailyLimit: 150,
          referralBonus: 14
        };
      default:
        return {
          earnings: 0.0003,
          dailyLimit: 100, 
          referralBonus: 10
        };
    }
  };

  // Watch ad endpoint
  app.post("/api/ads/watch", async (req, res) => {
    try {
      const { userId } = req.body;
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const levelConfig = getLevelConfig(user.level);

      // Update user's daily limit based on current level if different
      if (user.dailyLimit !== levelConfig.dailyLimit) {
        await storage.updateUser(userId, {
          dailyLimit: levelConfig.dailyLimit,
        });
      }

      // Check if user has reached daily limit
      if (user.adsWatched >= levelConfig.dailyLimit) {
        return res.status(400).json({ message: "Daily ad limit reached" });
      }

      const earnings = levelConfig.earnings;
      
      // Create ad session
      const adSession = await storage.createAdSession({
        userId,
        earnings: earnings.toFixed(5),
      });

      // Check for level progression (level up every 10,000 ads for level 1->2)
      let newLevel = user.level;
      let levelUpBonus = 0;
      if (user.level === 1 && user.totalAds + 1 >= 10000) {
        newLevel = 2;
        levelUpBonus = 0.25; // $0.25 bonus for reaching Level 2
      } else if (user.level === 2 && user.totalAds + 1 >= 50000) {
        newLevel = 3;
        levelUpBonus = 0.50; // $0.50 bonus for reaching Level 3
      }

      // Update user data
      const totalEarnings = earnings + levelUpBonus;
      const updatedUser = await storage.updateUser(userId, {
        adsWatched: user.adsWatched + 1,
        dailyEarnings: (parseFloat(user.dailyEarnings) + totalEarnings).toFixed(5),
        totalAds: user.totalAds + 1,
        totalEarned: (parseFloat(user.totalEarned) + totalEarnings).toFixed(5),
        withdrawBalance: (parseFloat(user.withdrawBalance) + levelUpBonus).toFixed(5),
        level: newLevel,
        dailyLimit: getLevelConfig(newLevel).dailyLimit,
        lastAdWatch: new Date(),
      });

      // Send Telegram notifications
      try {
        if (user.telegramId) {
          // Send ad reward notification
          await sendNotification(user.telegramId, 'adReward', earnings.toFixed(6));
          
          // Send level up notification if leveled up
          if (newLevel > user.level) {
            await sendNotification(user.telegramId, 'levelUp', newLevel);
            // Send bonus notification for level up
            if (levelUpBonus > 0) {
              await sendNotification(user.telegramId, 'levelUpBonus', levelUpBonus.toFixed(2));
            }
          }
          
          // Send daily limit notification if reached
          if (updatedUser.adsWatched >= updatedUser.dailyLimit) {
            await sendNotification(user.telegramId, 'dailyLimitReached', updatedUser.dailyLimit, updatedUser.dailyEarnings);
          }
        }
      } catch (error) {
        console.error('Error sending user notifications:', error);
      }

      // Handle referral bonus
      if (user.referredBy) {
        const referrer = await storage.getUser(user.referredBy);
        if (referrer) {
          const referralBonusRate = newLevel === 2 ? 0.14 : 0.10; // Level-based bonus
          const referralBonus = earnings * referralBonusRate;
          await storage.updateUser(referrer.id, {
            referralEarnings: (parseFloat(referrer.referralEarnings) + referralBonus).toFixed(6),
            totalEarned: (parseFloat(referrer.totalEarned) + referralBonus).toFixed(6),
          });
          
          // Send referral bonus notification
          try {
            if (referrer.telegramId) {
              await sendNotification(referrer.telegramId, 'referralBonus', referralBonus.toFixed(6), user.username);
            }
          } catch (error) {
            console.error('Error sending referral notification:', error);
          }
        }
      }

      // Update mission progress
      const userMissions = await storage.getUserMissions(userId);
      for (const userMission of userMissions) {
        const mission = await storage.getMission(userMission.missionId);
        if (mission && mission.type === "watch_ads" && !userMission.completed) {
          const newProgress = userMission.progress + 1;
          const completed = newProgress >= mission.target;
          await storage.updateUserMission(userMission.id, {
            progress: newProgress,
            completed,
            completedAt: completed ? new Date() : null,
          });
        }
        // Check level up missions
        if (mission && mission.type === "level_up" && !userMission.completed) {
          const newProgress = updatedUser.totalAds;
          const completed = newProgress >= mission.target;
          await storage.updateUserMission(userMission.id, {
            progress: newProgress,
            completed,
            completedAt: completed ? new Date() : null,
          });
        }
      }

      res.json({ user: updatedUser, adSession });
    } catch (error) {
      res.status(400).json({ message: "Failed to record ad session", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Get user missions
  app.get("/api/users/:id/missions", async (req, res) => {
    try {
      const userMissions = await storage.getUserMissions(req.params.id);
      const missions = await storage.getAllMissions();
      
      const missionsWithProgress = missions.map(mission => {
        const userMission = userMissions.find(um => um.missionId === mission.id);
        return {
          ...mission,
          progress: userMission?.progress || 0,
          completed: userMission?.completed || false,
          completedAt: userMission?.completedAt || null,
        };
      });

      res.json(missionsWithProgress);
    } catch (error) {
      res.status(500).json({ message: "Failed to get missions", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Claim daily earnings
  app.post("/api/users/:id/claim", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (user.adsWatched < user.dailyLimit) {
        return res.status(400).json({ message: "Daily limit not reached" });
      }

      const today = new Date().toDateString();
      const lastClaim = user.lastClaimDate ? new Date(user.lastClaimDate).toDateString() : null;
      
      if (lastClaim === today) {
        return res.status(400).json({ message: "Already claimed today" });
      }

      const updatedUser = await storage.updateUser(user.id, {
        withdrawBalance: (parseFloat(user.withdrawBalance) + parseFloat(user.dailyEarnings)).toFixed(5),
        dailyEarnings: "0.00000",
        adsWatched: 0,
        streak: lastClaim === new Date(Date.now() - 86400000).toDateString() ? user.streak + 1 : 1,
        lastClaimDate: new Date(),
      });

      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Failed to claim earnings", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Get user referrals
  app.get("/api/users/:id/referrals", async (req, res) => {
    try {
      const referrals = await storage.getUserReferrals(req.params.id);
      res.json(referrals);
    } catch (error) {
      res.status(500).json({ message: "Failed to get referrals", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Telegram bot start command endpoint
  app.post("/api/telegram/start", async (req, res) => {
    try {
      const { userId, chatId } = req.body;

      const botToken = '7561099955:AAF3Pc-C1-dhLiGqS_hwnegI5a9_55evHcQ';
      const botUsername = 'LightningSatsBot'; // Replace with your actual bot username
      const isAdmin = userId === 6653616672;

      const referralLink = `https://t.me/${botUsername}?start=${userId}`;

      const welcomeMessage = `
⚡️ <b>Welcome to Lightning Sats!</b>

💰 <b>Start your Passive Income journey today:</b>

🔥 <b>How it works:</b>
• Watch ads and earn real money  
• Level 1: $0.0003 per ad (100 ads daily)  
• Level 2: $0.0006 per ad (150 ads daily) + 14% referral bonus  

📈 <b>Monthly Passive Income Potential:</b>  
• Level 1: Up to $9/month  
• Level 2: Up to $27/month + referral earnings  

🎯 <b>Getting Started:</b>  
1. Watch your first ad to start earning  
2. Complete daily missions for bonuses  
3. Invite friends and earn 10–14% from their activity  
4. Watch 100 ads to level up  
5. Withdraw once you reach $1.00  

💎 <b>Premium Features:</b>  
• Real-time earnings tracking  
• Mission rewards system  
• Referral program  
• Multiple withdrawal methods (USD BSC, Payeer)

📜 <b>Available Commands:</b>  
/referlink – View your referral link 🔗  
/withdraw – Withdraw your earnings 💸  
/help – FAQs and support ❓  
${isAdmin ? '/adminpanel – Admin controls ⚙️' : ''}

🔗 <b>Your Referral Link:</b>  
<a href="${referralLink}">${referralLink}</a>

🚀 Start now – your financial freedom awaits!
      `;

      // Send message via Telegram Bot API
      try {
        // Get the Web App URL (you'll need to replace this with your actual Replit URL)
        const webAppUrl = process.env.REPL_URL || `https://${process.env.REPLIT_DOMAINS?.split(',')[0] || 'your-repl-name.your-username.repl.co'}`;
        
        const telegramResponse = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            chat_id: chatId,
            text: welcomeMessage,
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            reply_markup: {
              inline_keyboard: [[
                {
                  text: "💰 Open AdEarn Bot",
                  web_app: {
                    url: webAppUrl
                  }
                }
              ]]
            }
          })
        });

        const telegramResult = await telegramResponse.json();

        res.json({
          message: "Start command received and message sent",
          telegramResult,
          userId,
          chatId
        });
      } catch (telegramError) {
        console.error('Telegram API error:', telegramError);
        res.json({
          message: "Start command received but message send failed",
          error: telegramError,
          userId,
          chatId
        });
      }
    } catch (error) {
      res.status(500).json({
        message: "Failed to handle start command",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Admin endpoints
  app.get("/api/admin/stats", async (req, res) => {
    try {
      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to get admin stats", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.get("/api/admin/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Failed to get users", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
