import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  referralCode: text("referral_code").notNull().unique(),
  referredBy: text("referred_by"),
  telegramId: text("telegram_id"),
  withdrawBalance: decimal("withdraw_balance", { precision: 10, scale: 5 }).default("0.00000").notNull(),
  dailyEarnings: decimal("daily_earnings", { precision: 10, scale: 5 }).default("0.00000").notNull(),
  adsWatched: integer("ads_watched").default(0).notNull(),
  dailyLimit: integer("daily_limit").default(20).notNull(),
  level: integer("level").default(1).notNull(),
  totalAds: integer("total_ads").default(0).notNull(),
  totalEarned: decimal("total_earned", { precision: 10, scale: 5 }).default("0.00000").notNull(),
  streak: integer("streak").default(0).notNull(),
  referralsCount: integer("referrals_count").default(0).notNull(),
  referralEarnings: decimal("referral_earnings", { precision: 10, scale: 5 }).default("0.00000").notNull(),
  lastAdWatch: timestamp("last_ad_watch"),
  lastClaimDate: timestamp("last_claim_date"),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
});

export const adSessions = pgTable("ad_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull().references(() => users.id),
  earnings: decimal("earnings", { precision: 10, scale: 5 }).notNull(),
  completedAt: timestamp("completed_at").default(sql`now()`).notNull(),
});

export const missions = pgTable("missions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  reward: decimal("reward", { precision: 10, scale: 5 }).notNull(),
  type: text("type").notNull(), // 'daily_checkin', 'watch_ads', 'invite_friends', 'level_up'
  target: integer("target").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
});

export const userMissions = pgTable("user_missions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull().references(() => users.id),
  missionId: text("mission_id").notNull().references(() => missions.id),
  progress: integer("progress").default(0).notNull(),
  completed: boolean("completed").default(false).notNull(),
  completedAt: timestamp("completed_at"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertAdSessionSchema = createInsertSchema(adSessions).omit({
  id: true,
  completedAt: true,
});

export const insertMissionSchema = createInsertSchema(missions).omit({
  id: true,
});

export const insertUserMissionSchema = createInsertSchema(userMissions).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type AdSession = typeof adSessions.$inferSelect;
export type Mission = typeof missions.$inferSelect;
export type UserMission = typeof userMissions.$inferSelect;
export type InsertAdSession = z.infer<typeof insertAdSessionSchema>;
export type InsertMission = z.infer<typeof insertMissionSchema>;
export type InsertUserMission = z.infer<typeof insertUserMissionSchema>;
